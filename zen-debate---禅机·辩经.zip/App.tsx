import React, { useState, useEffect, useRef } from 'react';
import { 
  Flower2, 
  Sparkles, 
  Brain, 
  ChevronRight, 
  CheckCircle2, 
  Lock, 
  Unlock, 
  Play, 
  XCircle, 
  AlertCircle, 
  Trophy, 
  RefreshCw, 
  Moon, 
  Mountain 
} from 'lucide-react';
import { 
  LEVELS, 
  getLevelQuestions, 
  PASS_THRESHOLD 
} from './data';
import { User, Level, LevelData, Option } from './types';

// --- Components ---

export default function App() {
  const [gameState, setGameState] = useState<'welcome' | 'level-select' | 'game' | 'zen-ending'>('welcome');
  const [user, setUser] = useState<User>({ name: '', totalScore: 0, unlockedLevel: 1 });
  const [currentLevelData, setCurrentLevelData] = useState<LevelData | null>(null);
  
  const renderScreen = () => {
    switch (gameState) {
      case 'welcome':
        return <WelcomeScreen onStart={(name) => {
          setUser(prev => ({ ...prev, name: name || '云游僧' }));
          setGameState('level-select');
        }} />;
      case 'level-select':
        return <LevelSelectScreen 
          user={user} 
          onSelectLevel={(level) => {
            const questions = getLevelQuestions(level.id);
            setCurrentLevelData({
              meta: level,
              questions: questions,
              currentIndex: 0,
              correctCount: 0,
              history: []
            });
            setGameState('game');
          }} 
        />;
      case 'game':
        return currentLevelData ? (
          <GameArena 
            levelData={currentLevelData}
            onExit={() => setGameState('level-select')}
            onLevelComplete={(passed, scoreEarned) => {
              const levelId = currentLevelData.meta.id;
              
              if (passed) {
                setUser(prev => ({
                  ...prev,
                  totalScore: prev.totalScore + scoreEarned,
                  unlockedLevel: Math.max(prev.unlockedLevel, levelId + 1)
                }));
                
                // 终极通关检查：如果通过了最后一关 (Level 6)
                if (levelId === LEVELS.length) {
                  setGameState('zen-ending');
                  return;
                }
              }
            }}
            onReturnToMenu={() => setGameState('level-select')}
          />
        ) : <div>Loading...</div>;
      case 'zen-ending':
        return <ZenEndingScreen user={user} onReturnToMenu={() => setGameState('level-select')} />;
      default:
        return <div>Unknown State</div>;
    }
  };

  return (
    <div className="min-h-screen bg-stone-100 text-stone-800 font-sans selection:bg-amber-200">
      <div className="max-w-md mx-auto min-h-screen bg-white shadow-2xl overflow-hidden relative flex flex-col">
        <header className="bg-stone-900 text-amber-50 p-4 flex justify-between items-center shadow-lg z-10">
          <div className="flex items-center space-x-2">
            <Flower2 className="w-5 h-5 text-amber-500" />
            <h1 className="font-serif text-lg tracking-wider">禅机·辩经</h1>
          </div>
          {gameState !== 'welcome' && (
            <div className="flex items-center text-xs bg-stone-800 px-3 py-1 rounded-full border border-stone-700">
              <Sparkles className="w-3 h-3 mr-1 text-amber-500" />
              <span>功德分: {user.totalScore}</span>
            </div>
          )}
        </header>

        <main className="flex-1 overflow-y-auto relative bg-stone-50">
          {renderScreen()}
        </main>
      </div>
    </div>
  );
}

// --- 1. 欢迎界面 ---
interface WelcomeScreenProps {
  onStart: (name: string) => void;
}

function WelcomeScreen({ onStart }: WelcomeScreenProps) {
  const [name, setName] = useState('');

  return (
    <div className="h-full flex flex-col justify-center items-center p-8 bg-stone-50 text-center relative overflow-hidden">
      <div className="absolute top-10 right-10 text-9xl text-stone-200 font-serif opacity-50 pointer-events-none select-none">
        悟
      </div>
      
      <div className="z-10 w-full animate-in fade-in zoom-in duration-700">
        <div className="w-24 h-24 bg-stone-200 rounded-full mx-auto mb-6 flex items-center justify-center border-4 border-stone-300 shadow-inner">
          <Brain className="w-12 h-12 text-stone-500" />
        </div>
        
        <h2 className="text-3xl font-serif text-stone-900 mb-2">千题辩经</h2>
        <p className="text-stone-500 mb-8 text-sm">每关五问，全对通过，方证菩提</p>

        <div className="bg-white p-6 rounded-2xl shadow-sm border border-stone-200 mb-6">
          <label className="block text-left text-xs font-bold text-stone-400 uppercase tracking-wider mb-2">
            施主法号 (游客)
          </label>
          <input
            type="text"
            placeholder="请输入您的称呼..."
            className="w-full bg-stone-100 border-none rounded-lg p-3 text-stone-800 focus:ring-2 focus:ring-amber-500 outline-none transition-all"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
        </div>

        <button
          onClick={() => onStart(name)}
          className="w-full bg-stone-800 hover:bg-stone-900 text-amber-50 py-4 rounded-xl font-medium transition-all transform active:scale-95 flex items-center justify-center space-x-2 shadow-lg shadow-stone-400/50"
        >
          <span>开启试炼</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}

// --- 2. 关卡选择 ---
interface LevelSelectScreenProps {
  user: User;
  onSelectLevel: (level: Level) => void;
}

function LevelSelectScreen({ user, onSelectLevel }: LevelSelectScreenProps) {
  return (
    <div className="p-6 min-h-full pb-20">
      <div className="mb-6">
        <h2 className="text-2xl font-serif text-stone-800">六度海量题库</h2>
        <p className="text-stone-500 text-sm">当前题库总量: 1000+ | 每关随机抽取 5 题</p>
      </div>

      <div className="grid gap-4">
        {LEVELS.map((level) => {
          const isLocked = level.id > user.unlockedLevel;
          const isPassed = level.id < user.unlockedLevel;
          
          return (
            <button 
              key={level.id}
              disabled={isLocked}
              onClick={() => onSelectLevel(level)}
              className={`
                relative p-4 rounded-xl border text-left transition-all duration-300 flex items-start group
                ${isLocked 
                  ? 'bg-stone-100 border-stone-200 opacity-60 cursor-not-allowed' 
                  : isPassed 
                    ? 'bg-amber-50 border-amber-200 hover:shadow-md'
                    : 'bg-white border-stone-300 hover:border-amber-500 hover:shadow-lg ring-amber-200 hover:ring-2'
                }
              `}
            >
              <div className={`
                mt-1 w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold mr-3 flex-shrink-0
                ${isLocked ? 'bg-stone-200 text-stone-500' : isPassed ? 'bg-amber-500 text-white' : 'bg-stone-800 text-white'}
              `}>
                {isPassed ? <CheckCircle2 className="w-5 h-5" /> : level.id}
              </div>
              
              <div className="flex-1">
                <div className="flex justify-between items-center mb-1">
                  <h3 className="font-serif font-bold text-stone-800 group-hover:text-amber-700 transition-colors">
                    {level.title}
                  </h3>
                  {/* 通关后显示解锁，未通关（但可玩）显示解锁，上锁关卡显示上锁 */}
                  {level.id < user.unlockedLevel ? <Unlock className="w-4 h-4 text-green-500" /> : isLocked ? <Lock className="w-4 h-4 text-stone-400" /> : <Play className="w-4 h-4 text-amber-500" />}
                </div>
                <p className="text-xs text-stone-500 line-clamp-2">{level.description}</p>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}

// --- 3. 游戏主界面 ---
interface GameArenaProps {
  levelData: LevelData;
  onExit: () => void;
  onLevelComplete: (passed: boolean, scoreEarned: number) => void;
  onReturnToMenu: () => void;
}

function GameArena({ levelData, onExit, onLevelComplete, onReturnToMenu }: GameArenaProps) {
  const [currentIdx, setCurrentIdx] = useState(levelData.currentIndex);
  const [correctCount, setCorrectCount] = useState(levelData.correctCount);
  const [selectedOption, setSelectedOption] = useState<Option | null>(null);
  const [showFeedback, setShowFeedback] = useState(false);
  const [isLevelFinished, setIsLevelFinished] = useState(false);
  
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, []);

  const currentQuestion = levelData.questions[currentIdx];
  const totalQuestions = levelData.questions.length;
  const isLastQuestion = currentIdx === totalQuestions - 1;
  const maxCorrect = currentQuestion.maxCorrect || 1; 

  // 判定是否已经无法通关 (只要有一题错，就无法全对)
  const potentialLostCount = currentIdx - correctCount + (showFeedback && selectedOption && !selectedOption.isCorrect ? 1 : 0);
  const canPass = potentialLostCount === 0;

  const finishLevel = () => {
    setIsLevelFinished(true);
  };

  const nextQuestion = () => {
    if (isLastQuestion) {
      finishLevel();
    } else {
      setSelectedOption(null);
      setShowFeedback(false);
      setCurrentIdx(prev => prev + 1);
    }
  };

  const handleOptionClick = (option: Option) => {
    if (showFeedback) return;
    
    setSelectedOption(option);
    setShowFeedback(true);
    
    if (option.isCorrect) {
      // 答对了
      setCorrectCount(prev => prev + 1);
      
      // 自动跳转逻辑：延迟 1.5 秒后进入下一题或结算
      timerRef.current = setTimeout(() => {
         if (isLastQuestion) {
             finishLevel();
         } else {
             nextQuestion();
         }
      }, 1500); 

    } else {
      // 答错了：不自动跳转，让用户手动点击查看结果（因为错一题就失败）
    }
  };

  // 渲染关卡结算页
  if (isLevelFinished) {
    const passed = correctCount >= PASS_THRESHOLD;
    const score = correctCount * 10; 
    
    return (
      <LevelResultView 
        passed={passed}
        correctCount={correctCount}
        total={totalQuestions}
        levelTitle={levelData.meta.title}
        onContinue={() => {
            onLevelComplete(passed, score);
            onReturnToMenu();
        }}
        onRetry={() => {
            if(timerRef.current) clearTimeout(timerRef.current);
            onReturnToMenu(); 
        }}
      />
    );
  }

  // 如果答错且显示反馈，则用户已无法通关，必须手动点击查看结果
  const isCurrentlyFailed = showFeedback && selectedOption && !selectedOption.isCorrect;

  return (
    <div className="flex flex-col h-full relative">
      {/* 顶部进度栏 */}
      <div className="px-4 py-3 flex justify-between items-center text-xs z-10 bg-stone-50/90 backdrop-blur-sm sticky top-0 border-b border-stone-200">
        <div className="flex items-center space-x-4">
          <button onClick={onExit} className="text-stone-500 hover:text-stone-900 transition-colors">
            ← 退出
          </button>
          <span className="font-serif text-stone-600 font-bold">{levelData.meta.title}</span>
        </div>
        <div className="flex items-center space-x-2">
          <span className={`px-2 py-0.5 rounded ${canPass ? 'bg-amber-100 text-amber-800' : 'bg-red-100 text-red-800'}`}>
            {canPass ? '持戒中' : '破戒了'}
          </span>
          <span className="text-stone-400">
             进度: <span className="text-stone-800 font-bold">{currentIdx + 1}</span>/{totalQuestions}
          </span>
        </div>
      </div>

      {/* 进度条 */}
      <div className="w-full h-1 bg-stone-200">
        <div 
          className="h-full bg-amber-500 transition-all duration-500 ease-out"
          style={{ width: `${((currentIdx + 1) / totalQuestions) * 100}%` }}
        />
      </div>

      {/* 题目区 */}
      <div className="flex-1 px-6 pt-6 pb-24 overflow-y-auto">
        <div className="flex flex-col items-center mb-6 animate-in fade-in slide-in-from-top-4 duration-500">
          <h3 className="font-serif text-lg text-center text-stone-800 leading-relaxed mb-6 font-bold">
            {currentQuestion.q}
          </h3>
          
          {/* 选项 */}
          <div className="w-full space-y-3">
            {currentQuestion.options.map((option, index) => {
              let containerClass = "bg-white border-stone-200 hover:border-amber-400 hover:shadow-md";
              let textClass = "text-stone-700";
              let icon: React.ReactNode = String.fromCharCode(65 + index);
              let iconClass = "bg-white border-stone-300 text-stone-400";

              if (showFeedback) {
                if (selectedOption === option) {
                  // 用户选了这个
                  if (option.isCorrect) {
                    containerClass = "bg-green-50 border-green-500 ring-1 ring-green-500";
                    textClass = "text-green-900 font-medium";
                    iconClass = "bg-green-500 border-green-500 text-white";
                    icon = <CheckCircle2 className="w-4 h-4" />;
                  } else {
                    containerClass = "bg-red-50 border-red-400 ring-1 ring-red-400";
                    textClass = "text-red-900";
                    iconClass = "bg-red-400 border-red-400 text-white";
                    icon = <XCircle className="w-4 h-4" />;
                  }
                } else if (option.isCorrect) {
                  // 这是正确答案，但用户没选
                  containerClass = "bg-green-50 border-green-200 border-dashed";
                  textClass = "text-green-700";
                  iconClass = "bg-green-100 text-green-600 border-green-200";
                } else {
                  // 其他错误选项
                  containerClass = "opacity-40 grayscale";
                }
              }

              return (
                <button
                  key={index}
                  disabled={showFeedback}
                  onClick={() => handleOptionClick(option)}
                  className={`
                    w-full p-4 rounded-xl border text-left transition-all duration-200 flex items-center
                    ${containerClass}
                  `}
                >
                  <div className={`
                    w-7 h-7 rounded-full border flex items-center justify-center mr-3 text-xs font-bold flex-shrink-0 transition-colors
                    ${iconClass}
                  `}>
                    {icon}
                  </div>
                  <span className={`text-sm ${textClass}`}>{option.text}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* 反馈弹层 */}
      {showFeedback && selectedOption && (
        <div className="absolute bottom-0 left-0 right-0 bg-white rounded-t-3xl shadow-[0_-4px_30px_rgba(0,0,0,0.1)] border-t border-stone-100 p-6 z-20 animate-in slide-in-from-bottom duration-300">
          <div className="mb-4">
            <h4 className={`font-serif font-bold text-lg mb-1 flex items-center ${selectedOption.isCorrect ? 'text-green-700' : 'text-red-700'}`}>
              {selectedOption.isCorrect ? "正解" : "偏颇"}
              <span className="text-xs font-sans font-normal ml-2 text-stone-400 border border-stone-200 px-2 py-0.5 rounded-full">
                当前正确: {correctCount + (selectedOption.isCorrect ? 1 : 0)} / {currentIdx + 1}
              </span>
            </h4>
            <p className="text-sm text-stone-600 leading-relaxed">
              {selectedOption.feedback}
            </p>
            {/* 提示：如果此题有多个正确答案 */}
            {maxCorrect > 1 && selectedOption.isCorrect && (
                <p className="text-xs mt-2 text-stone-500 flex items-center">
                    <AlertCircle className="w-3 h-3 mr-1" />
                    此问可能有 <span className="font-bold mx-1">{maxCorrect}</span> 个角度，施主已得一解。
                </p>
            )}
          </div>

          <button
            onClick={() => {
                // 如果是答错，直接进入结算
                if (isCurrentlyFailed) {
                    if(timerRef.current) clearTimeout(timerRef.current);
                    finishLevel();
                } else if (isLastQuestion && selectedOption.isCorrect) {
                    // 如果答对且是最后一题，直接结算
                    if(timerRef.current) clearTimeout(timerRef.current);
                    finishLevel();
                }
                 else if (selectedOption.isCorrect) {
                    // 如果答对，且还在倒计时，清除倒计时并立即跳转下一题
                    if(timerRef.current) clearTimeout(timerRef.current);
                    nextQuestion();
                }
            }}
            className={`
              w-full py-3 rounded-xl font-medium transition-colors flex items-center justify-center text-white
              ${selectedOption.isCorrect ? 'bg-stone-800 hover:bg-stone-900' : 'bg-red-600 hover:bg-red-700'}
            `}
          >
            <span>
                {selectedOption.isCorrect 
                   ? (isLastQuestion ? "即将结算..." : "下一问") 
                   : "查看结果" // 答错直接查看结果（失败结算）
                }
            </span>
            <ChevronRight className="w-4 h-4 ml-1" />
          </button>
        </div>
      )}
    </div>
  );
}

// --- 4. 关卡小结界面 ---
interface LevelResultViewProps {
  passed: boolean;
  correctCount: number;
  total: number;
  levelTitle: string;
  onContinue: () => void;
  onRetry: () => void;
}

function LevelResultView({ passed, correctCount, total, levelTitle, onContinue, onRetry }: LevelResultViewProps) {
  return (
    <div className="h-full flex flex-col items-center justify-center p-8 bg-stone-50 text-center animate-in zoom-in duration-300">
      <div className={`w-20 h-20 rounded-full flex items-center justify-center mb-6 ${passed ? 'bg-amber-100 text-amber-600' : 'bg-stone-200 text-stone-500'}`}>
        {passed ? <Trophy className="w-10 h-10" /> : <RefreshCw className="w-10 h-10" />}
      </div>
      
      <h2 className="text-2xl font-serif font-bold text-stone-800 mb-2">
        {passed ? "圆满过关" : "修行未满"}
      </h2>
      
      <div className="text-5xl font-bold text-stone-900 mb-2 font-serif">
        {correctCount}<span className="text-2xl text-stone-400">/{total}</span>
      </div>
      
      <p className="text-stone-500 mb-8 max-w-xs text-sm leading-relaxed">
        {passed 
          ? `善哉！施主在"${levelTitle}"中展现了卓越的智慧，全题皆对。${levelTitle === LEVELS[LEVELS.length - 1].title ? '恭喜您完成所有试炼，请继续您的解脱之旅。' : '下一关已为您开启。'}` 
          : `可惜，通关需要答对 ${PASS_THRESHOLD} 题。心若浮躁，智慧难生，请重新来过。`
        }
      </p>

      <div className="w-full space-y-3">
        {passed ? (
          <button onClick={onContinue} className="w-full bg-amber-600 hover:bg-amber-700 text-white py-3 rounded-xl font-bold transition-all shadow-lg shadow-amber-200">
            {levelTitle === LEVELS[LEVELS.length - 1].title ? "进入禅寂之境" : "领取功德，下一关"}
          </button>
        ) : (
          <button onClick={onRetry} className="w-full bg-stone-800 hover:bg-stone-900 text-white py-3 rounded-xl font-bold transition-all">
            重新挑战
          </button>
        )}
      </div>
    </div>
  );
}

// --- 5. 禅寂完结界面 ---
interface ZenEndingScreenProps {
  user: User;
  onReturnToMenu: () => void;
}

function ZenEndingScreen({ user, onReturnToMenu }: ZenEndingScreenProps) {
    return (
        <div className="h-full flex flex-col items-center justify-center p-8 bg-stone-900 text-center relative overflow-hidden">
            <style>{`
                @keyframes pulse {
                    0% { transform: scale(1); opacity: 0.8; }
                    50% { transform: scale(1.1); opacity: 1; }
                    100% { transform: scale(1); opacity: 0.8; }
                }
                .zen-pulse {
                    animation: pulse 4s infinite ease-in-out;
                    filter: drop-shadow(0 0 10px rgba(255, 255, 255, 0.8));
                }
            `}</style>
            
            <Moon className="w-24 h-24 text-amber-300 zen-pulse mb-6" />

            <h2 className="text-4xl font-serif font-bold text-amber-50 mb-4 animate-in fade-in slide-in-from-top-4 duration-1000">
                彻悟圆满
            </h2>
            
            <p className="text-lg text-stone-300 mb-8 max-w-xs animate-in fade-in duration-1000 delay-300">
                施主，恭喜您圆满通关六度辩经。
                <br/><br/>
                所见一切法相，终归寂灭。
                <br/>
                <span className="font-serif italic text-amber-200">“无所得，故无所畏。”</span>
            </p>

            <div className="text-sm text-stone-400 mb-10 animate-in fade-in duration-1000 delay-500">
                <p>总功德分: <span className="text-amber-300 font-bold">{user.totalScore}</span></p>
                <p>法号: <span className="text-amber-300 font-bold">{user.name}</span></p>
            </div>

            <button 
                onClick={onReturnToMenu} 
                className="w-full max-w-[200px] bg-amber-500 hover:bg-amber-600 text-stone-900 py-3 rounded-xl font-bold transition-all shadow-lg shadow-amber-500/50 flex items-center justify-center space-x-2 animate-in fade-in slide-in-from-bottom-4 duration-1000 delay-700"
            >
                <Mountain className="w-4 h-4" />
                <span>回归世间</span>
            </button>
        </div>
    );
}